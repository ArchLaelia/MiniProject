import os
import os.path
from pathlib import Path
import PyPDF2
import time
import datetime
from datetime import datetime
import psutil
import platform
import socket
import sys
import pynvml as nvml
import shutil


def FindFiles(road):
    list_of_files = []
    # går igenom alla mappar och filer från road, neråt
    for root, dirs, files in os.walk(road, topdown=True):
        # för varje fil som kommer upp, lägg det i en lista
        for name in files:
            value = os.path.join(root, name)
            list_of_files.append(value)
    return list_of_files


def FindFileExt(folder, ext):
    list = []
    # listar alla filer i directory (folder)
    oslist = os.listdir(folder)
    for i in range(len(oslist)):
        # appendar alla filer som har ext, txt (.txt, .pdf etc)
        if oslist[i].endswith(ext):
            list.append(oslist[i])
    return list


def FindInfo(folder, pattern, ext):
    file_list = []
    list = []
    # går igenom alla mappar och filler från folder
    for root, dirs, files in os.walk(folder, topdown=True):
        # går igenom varje fil
        for file in files:
            # jämnför om de slutar med en extension
            if file.endswith(ext):
                file_list.append(os.path.join(root, file))
    for i in range(len(file_list)):
        # testar om filen finns, och om man har permission
        abspath = Path(file_list[i])
        try:
            pat = abspath.resolve(strict=True)
        except FileNotFoundError:
            continue
        except PermissionError:
            continue
        # välj en fil och skicka den till ReadFile för att läsa den
        file = ReadFile(file_list[i]).split()
        Flag = True
        x = 0
        if file is not None:
            while Flag is True and x < len(file):
                if pattern == file[x]:
                    list.append(file_list[i] + " contains " + pattern)
                    Flag = False
                else:
                    x += 1
    return list


def FindMod(folder, date):
    # behöver fixa denna
    # just nu jämnför den bara en fil
    # fun bör returna true eller false
    oslist = os.listdir(folder)
    list = []
    for file in oslist:
        modtime = os.path.getmtime(file)
        text = time.strftime('%Y-%m-%d-%H:%M:%S', time.localtime(modtime))
        d = datetime.datetime(int(text[0:4]), int(text[5:7]), int(text[8:10]),
                              0, 0, 0)
    # ans = str(input("Format: YYYY-MM-DD"))
        date = date.replace("-", "")
        w = datetime.datetime(int(date[0:4]), int(date[4:6]), int(date[6:8]),
                              0, 0, 0)
        if d >= w:
            list.append(file)
    return list


def FindDif(file1, file2):
    list1 = []
    list2 = []

    file1 = ReadFile(file1)
    for word in file1.split():
        list1.append(word)
    file2 = ReadFile(file2)
    for w in file2.split():
        list2.append(w)
    # count och få liknelse
    same = set(list1).intersection(list2)
    dif1 = set(list1).difference(list2)
    dif2 = set(list2).difference(list1)
    return same, dif1, dif2


def ReadFile(file_list):
    # När man läser filerna så kan det ge problem med decoding
    # Använder flera try except med olika encoding ifall någon inte funkar
    # if stats för att välja fil typ
    if file_list.endswith(".txt"):
        f = open(file_list, "r")
        try:
            file = f.read()
        except UnicodeDecodeError:
            f.close()
            f = open(file_list, "r", encoding="utf-8")
            try:
                file = f.read()
            except UnicodeDecodeError:
                f.close()
                f = open(file_list, "r", encoding="latin-1")
                try:
                    file = f.read()
                except UnicodeDecodeError:
                    print("send help")
        f.close()
    elif file_list.endswith(".pdf"):
        pdf_file = open(file_list, 'rb')
        read_pdf = PyPDF2.PdfFileReader(pdf_file)
        number_of_pages = read_pdf.getNumPages()
        count = 0
        file = ""
        while count < number_of_pages:
            page = read_pdf.getPage(count)
            count += 1
            allaord = page.extractText()
            file += allaord.strip("\n")
    return file


def DictCrypt():
    encrypt = {"a": "3", "b": "&", "c": "b", "d": "@", "e": "}", "f": "y",
                    "g": "!", "h": "x", "i": "q", "j": "k", "k": "#", "l": "w",
                    "m": "p", "n": "9", "o": "7", "p": "?", "q": "6", "r": "(",
                    "s": ")", "t": "=", "u": "2", "y": "*", "v": "€", "x": "^",
                    "z": "5", "å": "£", "ä": "4", "ö": ">", " ": "k"}
    return encrypt


def Encrypt(file):
    link = file
    head_tail = os.path.split(file)
    en = DictCrypt()
    file = ReadFile(link)
    f = open(head_tail[0] + "/encry" + head_tail[1], "w")
    for i in file:
        try:
            f.write(en[(i.lower())])
        except KeyError:
            f.write("\n")
    f.close()


def Decrypt(file):
    link = file
    name = os.path.split(file)
    en = DictCrypt()
    de = dict(zip(en.values(), en.keys()))
    file = ReadFile(link)
    f = open(name[0] + "/" + (name[1])[5:], "w")
    for i in file:
        try:
            f.write(de[i])
        except KeyError:
            f.write("\n")
    f.close()


def FindPC():
    # Boot Tiden
    # list of Stats
    list = []
    list.append("== Boot Tiden ==")
    boot_tid_timestamp = psutil.boot_time()
    bt = datetime.fromtimestamp(boot_tid_timestamp)
    list.append(f"Boot Tid: {bt.year}/{bt.month}/{bt.day} {bt.hour}:{bt.minute}:{bt.second}")
    list.append("")
    # CPU info
    list.append("== CPU Infomation ==")
    # antal cores
    list.append("Fysikska cores:" + str(psutil.cpu_count(logical=False)))
    list.append("Totalt cores:" + str(psutil.cpu_count(logical=True)))
    # CPU frequencies
    cpufreq = psutil.cpu_freq()
    list.append(f"Max Frequency: {cpufreq.max:.2f}Mhz")
    list.append(f"Min Frequency: {cpufreq.min:.2f}Mhz")
    list.append(f"Current Frequency: {cpufreq.current:.2f}Mhz")
    # CPU andvänding
    list.append("CPU använding per core:")
    for i, percentage in enumerate(psutil.cpu_percent(percpu=True)):
        list.append(f"Core {i}: {percentage}%")
    list.append(f"Total CPU användning: {psutil.cpu_percent()}%")

    # Memory Info
    list.append("== Memory Information ==")
    # memory detailjer
    sysmem = psutil.virtual_memory()
    list.append(f"Totalt: {sys.getsizeof(sysmem.total)}")
    list.append(f"Tiljängligt: {sys.getsizeof(sysmem.available)}")
    list.append(f"Andvänt: {sys.getsizeof(sysmem.used)}")
    list.append(f"Percentage: {sysmem.percent}%")

    list.append("")
    list.append("== System Information ==")
    uname = platform.uname()
    list.append(f"System: {uname.system}")
    list.append(f"Node Namn: {uname.node}")
    list.append(f"Release: {uname.release}")
    list.append(f"Version: {uname.version}")
    list.append(f"Maskin: {uname.machine}")
    list.append(f"Processor: {uname.processor}")

    list.append("== Disk Information ==")
    total, used, free = shutil.disk_usage("/")
    list.append("Totalt: %d GB" % (total // (2**30)))
    list.append("Använt: %d GB" % (used // (2**30)))
    list.append("Tiljängligt: %d GB" % (free // (2**30)))

    return list
