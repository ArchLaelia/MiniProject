import mainfun
import sys


def intro():
    print("-#- Welcome -#-.")
    print("Use the command -help foor addictional info")


def hel():
    print("Avaible commands:")
    print("-walkdir, [directory]")
    print("-modfile, [file], [date]")
    print("-walkext [folder], [extension]")
    print("-walkinfo [folder], [pattern], [extension]")
    print("-encrypt [file]")
    print("-decrypt [file]")
    print("-compfile [file1], [file2]")


def main():
    intro()
    while True:
        ans = str(input()).split()
        if ans[0] == "-help":
            hel()
        elif ans[0] == "-modfile":
            modlist = mainfun.FindMod(ans[1], ans[2])
            for q in range(len(modlist)):
                print(modlist[q])
        elif ans[0] == "-walkdir":
            print("File Search: Start")
            list = mainfun.FindFiles(ans[1])
            print("Files search: Complete")
            i = 0
            Flag = True
            while Flag is True:
                if i % 5 != 0:
                    try:
                        print(list[i])
                    except IndexError:
                        print("List empty")
                        Flag = False
                else:
                    con = str(input("Continue? Enter if yes, q if no"))
                    if con == "q":
                        Flag = False
                i += 1
        elif ans[0] == "-walkext":
            print("File Search: Start")
            list = mainfun.FindFileExt(ans[1], ans[2])
            print("Files search: Complete")
            i = 0
            Flag = True
            while Flag is True:
                if i % 5 != 0:
                    try:
                        print(list[i])
                    except IndexError:
                        print("List empty")
                        Flag = False
                else:
                    con = str(input("Continue? Enter if yes, q if no"))
                    if con == "q":
                        Flag = False
                i += 1
        elif ans[0] == "-walkinfo":
            print("File Search: Start")
            list = mainfun.FindInfo(ans[1], ans[2], ans[3])
            print("Files search: Complete")
            i = 0
            x = 1
            Flag = True
            while Flag is True:
                if x % 5 != 0:
                    try:
                        print(list[i])
                    except IndexError:
                        print("List empty")
                        Flag = False
                else:
                    con = str(input("Continue? Enter if yes, q if no"))
                    if con == "q":
                        Flag = False
                i += 1
                x += 1
        elif ans[0] == "-encrypt":
            print("Encrypting...")
            mainfun.Encrypt(ans[1])
            print("Encryption: Complete")
        elif ans[0] == "-decrypt":
            print("Decrypting...")
            mainfun.Decrypt(ans[1])
            print("Decrypting: Complete")
        elif ans[0] == "-compfile":
            numstup = mainfun.FindDif(ans[1], ans[2])
            print("Words shared: " + str(numstup[0]))
            print("Unique words in File1: " + str(numstup[1]))
            print("Unique words in File2: " + str(numstup[2]))
        elif ans[0] == "q":
            sys.exit()
        else:
            print("enter correct command")
