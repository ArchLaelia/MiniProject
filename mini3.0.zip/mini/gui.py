from tkinter import *
import os
import datetime
import mainfun
import PyPDF2

class MyGUI:
    def __init__(self):
        def create_window():
            second_window = Toplevel(self.main_window)
            top_frame = Frame(second_window)
            bottom_frame = Frame(second_window)
            middle_frame = Frame(second_window)
            top_frame.pack()
            bottom_frame.pack()
            middle_frame.pack()

            prompt_label = Label(top_frame, text="Enter the Directory: ")
            prompt_label.pack(side=LEFT)
            path_entry = Entry(top_frame, width=30)
            path_entry.pack(side=LEFT)

            describe_label = Label(middle_frame, text="Results:", font=("arial", 20, "bold"))
            value = StringVar()

            result_label = Message(middle_frame, textvariable=value, font=("arial", 10, "bold"))
            describe_label.pack(side=LEFT)
            result_label.pack(side=LEFT)

            def list_files():
                list = []
                path = path_entry.get()
                value.set(mainfun.FindFiles(path))

            function_button = Button(bottom_frame, text="Search", command=list_files)
            quit_button = Button(bottom_frame, text="Quit", command=second_window.quit)

            function_button.pack(side=LEFT)
            quit_button.pack(side=LEFT)

        # -----------------------------------------------------------------------------#
        def create_window2():
            second_window = Toplevel(self.main_window)
            top_frame = Frame(second_window)
            bottom_frame = Frame(second_window)
            middle_frame = Frame(second_window)
            top_frame.pack()
            bottom_frame.pack()
            middle_frame.pack()

            prompt_label = Label(top_frame, text="Enter the path for file: ")
            prompt_label.pack(side=LEFT)
            path_entry = Entry(top_frame, width=30)
            path_entry.pack(side=LEFT)

            extension_label = Label(top_frame, text="Enter the file extension: ")
            extension_label.pack(side=LEFT)
            extension_entry = Entry(top_frame, width=30)
            extension_entry.pack(side=LEFT)

            describe_label = Label(middle_frame, text="Results:", font=("arial", 20, "bold"))
            value = StringVar()
            result_label = Message(middle_frame, textvariable=value, font=("arial", 10, "bold"))
            describe_label.pack(side=LEFT,)
            result_label.pack(side=LEFT)

            def extension():
                list = []
                dir = path_entry.get()
                ext = extension_entry.get()
                value.set(mainfun.FindFileExt(dir, ext))

            function_button = Button(bottom_frame, text="Search", command=extension)
            quit_button = Button(bottom_frame, text="Quit", command=second_window.quit)

            function_button.pack(side=LEFT)
            quit_button.pack(side=LEFT)

        # ---------------------------------------------------------------------------------------------------#
        def create_window3():
            second_window = Toplevel(self.main_window)
            top_frame = Frame(second_window)
            bottom_frame = Frame(second_window)
            middle_frame = Frame(second_window)
            top_frame.pack()
            bottom_frame.pack()
            middle_frame.pack()

            word_label = Label(top_frame, text="Enter Keyword:")
            word_label.pack(side=LEFT)
            word_entry = Entry(top_frame, width=30)
            word_entry.pack(side=LEFT)

            path_label = Label(top_frame, text="Enter Folder:")
            path_label.pack(side=LEFT)
            path_entry = Entry(top_frame, width=30)
            path_entry.pack(side=LEFT)

            ext_label = Label(top_frame, text="Extension")
            ext_label.pack(side=LEFT)
            ext_entry = Entry(top_frame, width=30)
            ext_entry.pack(side=LEFT)

            describe_label = Label(middle_frame, text="Results:", font=("arial", 10)).pack(side=LEFT)
            value_files = StringVar()
            result_label = Label(middle_frame, textvariable=value_files, font=("arial", 15, "bold"))
            result_label.pack(side=LEFT)

            def word_search():
                ord = word_entry.get()
                folder = path_entry.get()
                ext = ext_entry.get()
                value_files.set(mainfun.FindInfo(folder, ord, ext))

            function_button = Button(bottom_frame, text="Search", command=word_search)
            quit_button = Button(bottom_frame, text="Quit", command=second_window.quit)

            function_button.pack(side=LEFT)
            quit_button.pack(side=LEFT)

        # -----------------------------------------------------------------------------------------------------------------------#
        def create_window4():

            second_window = Toplevel(self.main_window)
            top_frame = Frame(second_window)
            bottom_frame = Frame(second_window)
            middle_frame = Frame(second_window)
            top_frame.pack()
            bottom_frame.pack()
            middle_frame.pack()

            describe_label1 = Label(middle_frame, text="Result:").pack(side=LEFT)
            value_number = StringVar()
            result_label = Message(middle_frame, textvariable=value_number, font=("arial", 15)).pack(side=LEFT)

            def pc():
                value_number.set(mainfun.FindPC())

            function_button = Button(bottom_frame, text="Get Info", command=pc)
            quit_button = Button(bottom_frame, text="Quit", command=second_window.quit)

            function_button.pack(side=LEFT)
            quit_button.pack(side=LEFT)

        # ------------------------------------------------------------------------------------------------------------------------#
        def create_window5():
            second_window = Toplevel(self.main_window)
            top_frame = Frame(second_window)
            bottom_frame = Frame(second_window)
            middle_frame = Frame(second_window)
            top_frame.pack()
            bottom_frame.pack()
            middle_frame.pack()

            file_label = Label(top_frame, text="Insert the path to the file:").pack(side=LEFT)
            file_entry = Entry(top_frame, width=35)
            file_entry.pack(side=LEFT)
            file_path_label = Label(top_frame, text="Name of the file for encrypting").pack(side=LEFT)
            file_path_entry = Entry(top_frame, width=35)
            file_path_entry.pack(side=LEFT)

            def encrypt_file():
                file_input = file_entry.get()
                mainfun.Encrypt(file_input)
                # file_name_input = file_path_entry.get()



            function_button = Button(middle_frame, text="Encrypt", command=encrypt_file).pack(side=LEFT)
            quit_button = Button(middle_frame, text="Quit", command=second_window.quit).pack(side=LEFT)

# -------------------------------------------------------------------------------------------------------------------
        def create_window6():
            second_window = Toplevel(self.main_window)
            top_frame = Frame(second_window)
            bottom_frame = Frame(second_window)
            middle_frame = Frame(second_window)
            top_frame.pack()
            bottom_frame.pack()
            middle_frame.pack()

            file_label = Label(top_frame, text="Enter file A: ").pack(side=LEFT)
            file_entry = Entry(top_frame, width=30)
            file_entry.pack(side=LEFT)
            file_label2 = Label(top_frame, text=("Enter file B:")).pack(side=LEFT)
            file_entry2 = Entry(top_frame, width=30)
            file_entry2.pack(side=LEFT)

            Label_samma = Label(bottom_frame, text="Words in both files:").pack(side=LEFT)
            result_samma = StringVar()
            resultat = Message(bottom_frame, textvariable=result_samma, font=("arial", 10, "bold")).pack(side=LEFT)

            label_Ainteb = Label(bottom_frame, text="Words in B not A:").pack(side=LEFT)
            result_AinteB = StringVar()
            resultat_aob = Message(bottom_frame, textvariable=result_AinteB, font=("arial", 10, "bold")).pack(side=LEFT)

            label_BinteA = Label(bottom_frame, text="Words in A not B:").pack(side=LEFT)
            result_BinteA = StringVar()
            result_BoA = Message(bottom_frame, textvariable=result_BinteA, font=("arial", 10, "bold")).pack(side=LEFT)

            def Alla():
                forstafil = file_entry.get()
                andrafil = file_entry2.get()
                same_tup = mainfun.FindDif(forstafil, andrafil)
                result_samma.set(same_tup[0])
                result_AinteB.set(same_tup[1])
                result_BinteA.set(same_tup[2])


            function_button = Button(middle_frame, text="Search", command=Alla).pack(side=LEFT)
            quit_button = Button(middle_frame, text="Quit", command=second_window.quit).pack(side=LEFT)

# ------------------------------------------------------------------------------------------------------------------
        def create_window7():
            second_window = Toplevel(self.main_window)
            top_frame = Frame(second_window)
            bottom_frame = Frame(second_window)
            middle_frame = Frame(second_window)
            top_frame.pack()
            bottom_frame.pack()
            middle_frame.pack()

            year_label = Label(top_frame, text="Insert time for comparing: ")
            year_label.pack(side=LEFT)
            word_entry = Entry(top_frame, width=30)
            word_entry.pack(side=LEFT)

            path_label = Label(top_frame, text="Enter the path: ")
            path_label.pack(side=LEFT)
            path_entry = Entry(top_frame, width=40)
            path_entry.pack(side=LEFT)

            describe_label = Label(middle_frame, text="Displaying the results:")
            value = StringVar()
            result_label = Label(middle_frame, textvariable=value)
            describe_label.pack(side=LEFT)
            result_label.pack(side=LEFT)

            def modified_files():
                fname = mainfun.FindMod(path_entry.get(), word_entry.get())
                value.set(fname)

            function_button = Button(bottom_frame, text="Search", command=modified_files).pack(side=LEFT)
            quit_button = Button(bottom_frame, text="Quit", command=second_window.quit).pack(side=LEFT)

#----------------------------------------------------------------------------------------------------------------------

        def create_window8():
            second_window = Toplevel(self.main_window)
            top_frame = Frame(second_window)
            bottom_frame = Frame(second_window)
            middle_frame = Frame(second_window)
            top_frame.pack()
            bottom_frame.pack()
            middle_frame.pack()

            label1 = Label(top_frame, text="Enter path to file:").pack(side=LEFT)
            entry_1 = Entry(top_frame, width=30)
            entry_1.pack(side=LEFT)

            label2 = Label(top_frame, text="Enter Filename:").pack(side=LEFT)
            entry_2 = Entry(top_frame, width=30)
            entry_2.pack(side=LEFT)

            def decrypt_file():
                file_input = entry_1.get()
                mainfun.Decrypt(file_input)

            function_button = Button(bottom_frame, text="Decrypt", command=decrypt_file).pack(side=LEFT)
            quit_button = Button(bottom_frame, text="Quit", command=second_window.quit).pack(side=LEFT)



        #######HUVUD MENU##########
        self.main_window = Tk()
        self.main_window.title("ProjektArbete")
        self.label_title = Label(self.main_window, text="HUVUDMENY", fg="white", bg="grey",
                                 font=("castellar", 40, "bold")).pack(side=TOP, fill=X)
        self.menu1 = Button(self.main_window, text="Find Files", fg="Red", font=("arial", 15, "bold"),
                            command=create_window).pack(side=LEFT)
        self.menu2 = Button(self.main_window, text="File Type", fg="Red", font=("arial", 15, "bold"),
                            command=create_window2).pack(side=LEFT)
        self.menu3 = Button(self.main_window, text="Search Keyword", fg="Red", font=("arial", 15, "bold"),
                            command=create_window3).pack(side=LEFT)
        self.menu4 = Button(self.main_window, text="PC Stats", fg="Red", font=("arial", 15, "bold"),
                            command=create_window4).pack(side=LEFT)
        self.menu5 = Button(self.main_window, text="Encrypt textfile", fg="Red", font=("arial", 15, "bold"),
                            command=create_window5).pack(side=LEFT)
        self.menu6 = Button(self.main_window, text="Decrypt textfile", fg="Red", font=("arial", 15, "bold"), command=create_window8).pack(side=LEFT)
        self.menu7 = Button(self.main_window, text="Compare Files", fg="Red", font=("arial", 15, "bold"), command=create_window6).pack(side=LEFT)
        self.menu8 = Button(self.main_window, text="Modified Files", fg="Red", font=("arial", 15, "bold"), command=create_window7).pack(side=LEFT)
        ###########################################################################################################################################

        # -------------------------------------------------------------------------------------------------------------
        mainloop()

start = MyGUI()
